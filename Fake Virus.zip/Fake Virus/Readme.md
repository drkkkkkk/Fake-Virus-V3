To get this working you will see the "Fake virus.zip" If you don't see that re-install the script/zip where as if you can see the ZIP you need to extract to. Once you have done extract to you need to locate "Fake Virus.vbs" Then run that file. The .vbs file is the fake virus it's self. if you want to close the script then close it using task manager, this does NOTHING to you're pc and I have fully tested it. If you want to speak to me about it before you run it then contact me on discord drkplayz#6969 


!!WARNING!! When you run the file it will say there is a malware! it's part of the script!!!
this does not contain a virus, do a scan if you really want to!!